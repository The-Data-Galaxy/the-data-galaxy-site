# EDPB Template for Personal Data Breach Notification — Draft Working Copy

> Use this field order for every supervisory-authority notification draft. It follows the EDPB Version 1.0 consultation DOCX adopted on 08 June 2026. Keep `[TO CONFIRM]` for unknown values and use conditional fields only when their trigger applies.

## 1. Information on the personal data breach notification [Field 1]

### 1.1 Type of notification [Field 2]

- **3. Type of notification:** New Notification / Follow-Up Notification
- **4. Sub-type of notification:** Complete / Incomplete / Withdraw
- **5. Reasons for withdrawing a previous notification:** `[if visible]`
- **6. ID of previously notified personal data breach:** `[if applicable]`
- **7. Data controller's internal reference number:** `[TO CONFIRM]`

## 2. Identification of the data controller and the reporting person [Field 8]

### 2.1 About the data controller [Field 9]

- **10. Type of Identifier:** `[if applicable]`
- **11. Identifier:** `[if applicable]`
- **12. Name of the organisation:** `[TO CONFIRM]`
- **13. Contact details*:** `[TO CONFIRM]`
- **14. Sector:** Private / Public / `[TO CONFIRM]`
- **15. Type of organisation:** `[if private]`
- **16. Further description of organisation type:** `[if other]`
- **17. Classification of economic activity:** `[TO CONFIRM]`
- **18. Name of representative in EEA:** `[if controller not established in EEA]`
- **19. Contact details* of representative in EEA:** `[if applicable]`

### 2.2 Identity of the reporting person [Field 20]

- **21. Name of the reporting person:** `[TO CONFIRM]`
- **22. Contact details:** `[TO CONFIRM]`
- **23. Function of the reporting person:** DPO / Legal representative / Authorised representative or other
- **24. Description of the function of the reporting person:** `[if other]`
- **25. National identification number:** `[if required]`
- **26. Accuracy & Responsibility:** `[if required]`

### 2.3 Name and contact details of the DPO or other contact point [Field 27]

#### 2.3.1 About the data protection officer [Field 28]

- **29. Is a data protection officer designated?:** `[TO CONFIRM]`
- **30. Name of the DPO:** `[if applicable]`
- **31. Contact details*:** `[if applicable]`
#### 2.3.2 About the contact point where more information can be obtained [Field 32]

- **33. More information about the incident can be obtained at:** DPO / Reporting person / Other
- **34. Name of the contact person:** `[if visible]`
- **35. Function of the contact person:** `[if visible]`
- **36. Contact details*:** `[if visible]`

### 2.4 Involvement of other parties [Field 37]

- **38. Are other parties such as data processors or joint controllers involved?:** Yes / No
- **39. Qualification of the other involved party:** `[if yes]`
- **40. Name of the other involved party:** `[if yes; repeatable]`
- **41. Contact details*:** `[if yes]`

## 3. Initial information on the personal data breach [Field 42]

### 3.1 Date and time of the breach and its detection [Field 43]

- **44. When did the personal data breach occur?:** Specific day / Date range / From date and ongoing / Cannot be determined / To be determined
- **45. Only estimated dates are possible:** `[checkbox if applicable]`
- **46. Beginning date and time of personal data breach:** `[if visible]`
- **47. Ending date and time of personal data breach:** `[if visible]`
- **48. Date and time of awareness of the data controller:** `[TO CONFIRM]`
- **49. Reasons for late notification of the personal data breach:** `[if visible]`
- **50. How was the personal data breach discovered?:** `[select official option]`
- **51. Further description of the discovery of the personal data breach:** `[TO CONFIRM]`
- **52. Date of notification by other party:** `[if visible]`
- **53. Further comments on timeline and additional information:** `[TO CONFIRM]`

### 3.2 Nature, circumstances and summary [Field 54]

- **55. Nature of the personal data breach:** Confidentiality / Integrity / Availability
- **56. Type of confidentiality breach:** `[if confidentiality]`
- **57. Was the data unintelligible to anyone not authorised to access it or were individuals not identifiable?:** `[if confidentiality]`
- **58. Type of integrity breach:** `[if integrity]`
- **59. Type of availability breach:** Temporary / Permanent / Not determined `[if availability]`
- **60. Nature of the incident:** `[select official option(s)]`
- **61. Cause of the personal data breach:** Internal non-malicious / Internal malicious / External non-malicious / External malicious / To be determined / Unknown
- **62. Further description of the nature of the incident:** `[TO CONFIRM]`
- **63. Description of the systems, software, services, and infrastructures involved and where located:** `[TO CONFIRM]`

### 3.3 Categories and number of data subjects concerned [Field 64]

- **65. Categories of concerned data subjects:** `[select official option(s)]`
- **66. Further description of categories of concerned data subjects and additional data subjects:** `[if applicable]`
- **67. Data subjects concerned by the personal data breach:** Exact / Approximate / Cannot be determined / To be determined
- **68. Number of data subjects concerned by the personal data breach:** `[if exact or approximate]`

### 3.4 Categories and number of personal data records concerned [Field 69]

- **70. Type of breached data:** `[select official option(s)]`
- **71. Further description of breached data and additional data categories:** `[if applicable]`
- **72. Personal data records concerned by the personal data breach:** Exact / Approximate / Cannot be determined / To be determined
- **73. Number of personal data records concerned by the personal data breach:** `[if exact or approximate]`

### 3.5 Measures in place when the breach occurred [Field 74]

- **75. Relevant measures in place when the personal data breach occurred:** `[select official option(s)]`
- **76. Further description of relevant measures in place when the personal data breach occurred:** `[TO CONFIRM]`

## 4. Further information on the personal data breach [Field 77]

### 4.1 Likely consequences and adverse effects [Field 78]

- **79. Likely consequences in case of breach of confidentiality:** `[if confidentiality]`
- **80. Description of other confidentiality consequences:** `[if applicable]`
- **81. Likely consequences in case of breach of integrity:** `[if integrity]`
- **82. Description of other integrity consequences:** `[if applicable]`
- **83. Likely consequences in case of breach of availability:** `[if availability]`
- **84. Description of other availability consequences:** `[if applicable]`
- **85. Nature of the potential impact for the data subject:** `[select official option(s)]`
- **86. Further description of other impacts for the data subjects:** `[if applicable]`
- **87. Severity of the potential impacts:** Minor / Moderate / Severe / To be determined

### 4.2 Assessment of risk [Field 88]

- **89. Outcome of the risk assessment carried out by the controller:** High risk / Risk / Unlikely risk / Additional information needed
- **90. Further description of the risk assessment carried out by the data controller:** `[TO CONFIRM]`

### 4.3 Measures to address and mitigate [Field 91]

- **92. Measures taken to address the personal data breach and to mitigate its consequences:** `[TO CONFIRM]`

### 4.4 Measures to prevent similar breach [Field 93]

- **94. Relevant measures taken to prevent similar personal data breach:** `[select official option(s)]`
- **95. Further description of relevant updated permanent measures to avoid similar incidents:** `[TO CONFIRM]`

## 5. Communication to the data subjects [Field 96]

- **97. Has the personal data breach been communicated to data subjects?:** `[select official option]`
- **98. Date of when information was given to data subjects:** `[if visible]`
- **99. Future date on which the data breach will be communicated to data subjects:** `[if visible]`
- **100. Further information about conditions referred to in Article 34(3) GDPR:** `[if visible]`
- **101. Further description why Article 34(3) conditions are met and measures taken:** `[if visible]`
- **102. Number of data subjects informed:** `[if visible]`
- **103. Further description why not all data subjects have been informed:** `[if visible]`
- **104. Means of communication used to inform the data subject:** `[if visible]`
- **105. Further description of other means of communication:** `[if visible]`
- **106. Content of the information provided to the data subjects:** `[if visible]`

## 6. Possible other issues [Field 107]

### 6.1 Other authorities or bodies [Field 108]

- **109. Has the incident been reported to police/judicial authorities as a criminal offence?:** Yes / No / Unknown
- **110. Has the incident been notified to other supervisory authorities or control bodies under other relevant legislation?:** Yes / No / Unknown
- **111. Further information about notification to other authorities or bodies:** `[if visible]`

### 6.2 Cross-border processing — controller established in EEA [Field 112]

- **113. Does the breach involve cross-border processing carried out by a controller established in the EEA?:** Yes / No / Unknown
- **114. The lead supervisory authority is:** `[if visible]`
- **115. List of EEA countries where the controller has an establishment:** `[if visible]`
- **116. List of EEA countries where affected data subjects are located:** `[if visible]`
- **117. Approximate number of data subjects per country:** `[if visible]`
- **118. List of EEA supervisory authorities to which the breach has been or will be notified:** `[if visible]`

### 6.3 Non-EEA establishments [Field 119]

- **120. Does the breach involve GDPR processing carried out by a controller not established in the EEA?:** Yes / No / Unknown
- **121. List of EEA countries where affected data subjects are located:** `[if visible]`
- **122. Approximate number of data subjects per country:** `[if visible]`
- **123. List of EEA supervisory authorities to which the breach has been or will be notified:** `[if visible]`

## 7. Attachments [Field 124]

- **125. Please identify the attachments to this notification:** `[select official attachment option(s)]`
- **126. Other attachments:** `[if visible]`
