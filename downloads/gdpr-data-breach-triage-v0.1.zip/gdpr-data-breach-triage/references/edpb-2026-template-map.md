# EDPB 2026 Official Template Mapping (Consultation-Stage Reference)

## Status

The EDPB common personal data breach notification template was adopted on 08 June 2026 for public consultation and published on 10 June 2026. The consultation closes on 05 August 2026. The EDPB states that DPA implementation timing will be decided after consultation. Treat this as the official EDPB consultation template, not a final or universally implemented filing form.

Source page: <https://www.edpb.europa.eu/public-consultations/template-for-personal-data-breach-notification_en>

Bundled source authority: `assets/edpb_template_2026_data_breach_notification_v1.0_en.docx` (EDPB version 1.0, 132.74 KB).

## Mandatory drafting rule

When producing a notification draft, use `assets/notification-draft.md` exactly in its field-number order. Keep official English field labels and add concise Chinese assistance after the label only where useful. Do not omit a field merely because its value is unknown: use `[TO CONFIRM]`, the relevant official incomplete-notification option, or `not applicable` with a reason.

## Internal fact to official template section

| Internal fact | Draft section |
|---|---|
| Internal fact | EDPB field range |
|---|---|
| Notice type, completeness, previous notices | 3–7 |
| Controller, reporting person, DPO/contact, other parties | 10–41 |
| T0, T1, occurrence, discovery and timeline | 44–53 |
| Confidentiality, integrity, availability, incident, cause, systems | 55–63 |
| Data subjects, personal-data records and pre-existing measures | 65–76 |
| Consequences, impact, risk assessment and mitigating/preventive measures | 79–95 |
| Data-subject communication | 97–106 |
| Other authorities, cross-border/non-EEA issues and attachments | 109–126 |

## Drafting rules

- Use the current internal fact record as the source of truth.
- Mark estimates and unknowns explicitly.
- Do not invent local DPA fields, authority names, portal instructions, or implementation status.
- Preserve the distinction between a first notification, later update, and withdrawal only when supported by the case facts.
- Preserve official field identifiers and labels even where the consultation DOCX itself appears internally inconsistent; record explanatory notes separately rather than silently rewriting the official form.
- Keep legal advice, sensitive security detail, and unverified speculation out of the draft unless the user specifically asks for an internal working draft.
