# EDPB-Informed Scenario Cards

These cards compress recurring patterns from EDPB Guidelines 01/2021. They are prompts for fact collection, not automatic outcomes.

## 1. Misdirected email or file

Risk increases with sensitive data, multiple or unknown recipients, opening/download evidence, onward sharing, no deletion confirmation, or an untrusted recipient. Risk may be reduced by a single trusted recipient, confidentiality duties, prompt deletion, written confirmation, and no access or copying evidence. Verify recipient identity, access, copies, data sensitivity, and affected people.

## 2. Exposed cloud link or configuration

Risk increases with public indexing, long exposure, open download, sensitive data, unknown audience, or continued availability. Verify exposure window, access logs, downloads, search-engine caching, data scope, and containment. Do not infer that exposure equals confirmed access or that absence of logs proves no access.

## 3. Ransomware

Separate availability impact from confidentiality impact. Risk increases with evidence or credible possibility of exfiltration, sensitive data, long outage, weak backups, vulnerable people, or ongoing attacker access. Verify restoration, backup integrity, exfiltration indicators, credentials, and service impact. Do not wait for complete forensic certainty before considering a timely notification path.

## 4. Credential or account compromise

Risk increases with valid credentials, successful access, privilege escalation, financial or identity data, reuse across systems, and evidence of misuse. Verify affected accounts, access window, logs, reset and token revocation, MFA, and any downstream activity.

## 5. Lost device or media

Risk increases when the device is unencrypted, unlocked, the key is exposed, the data is unique, or the device is likely to be accessed. Verify encryption mode, key protection, remote wipe, backup availability, and data categories.

## 6. Employee over-access or unauthorised internal access

Risk increases with intentional misuse, broad export, sensitive data, onward sharing, or inability to identify the recipient. Verify authorisation, access logs, copies, intent, containment, and deletion or return.

## Use rule

Select the closest card only after extracting the actual facts. If more than one card applies, combine the relevant factors and state the uncertainty rather than forcing a single scenario label.
