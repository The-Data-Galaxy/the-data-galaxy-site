# GDPR / EDPB Core Rules

## Source status

This is a concise implementation aid, not a substitute for the official texts. Verify against the official sources before relying on a conclusion.

- GDPR consolidated text, Articles 4(12), 33 and 34: <https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=CELEX%3A32016R0679>
- EDPB Guidelines 9/2022, final version 2.0: <https://www.edpb.europa.eu/documents/guideline/guidelines-92022-on-personal-data-breach-notification-under-gdpr_en>
- EDPB Guidelines 01/2021 on examples: <https://www.edpb.europa.eu/documents/guideline/guidelines-012021-on-examples-regarding-personal-data-breach-notification_en>

## Article 4(12): personal data breach

Treat a personal data breach as a breach of security leading to accidental or unlawful destruction, loss, alteration, unauthorised disclosure of, or access to personal data transmitted, stored, or otherwise processed. The three operational lenses are confidentiality, integrity, and availability.

## Article 33: supervisory-authority notification

- The controller must notify the competent supervisory authority without undue delay and, where feasible, not later than 72 hours after becoming aware of the personal data breach.
- The exception is where the breach is unlikely to result in a risk to the rights and freedoms of natural persons.
- A notification after 72 hours must be accompanied by reasons for the delay.
- The notification should cover the nature of the breach, categories and approximate numbers where possible, contact details, likely consequences, and measures taken or proposed.
- Information may be provided in phases when it cannot all be supplied at the same time, without undue further delay.
- The controller documents every personal data breach, including facts, effects, and remedial action, even when no authority notification is made.

## Article 34: communication to data subjects

- Communicate without undue delay when the breach is likely to result in a high risk to the rights and freedoms of natural persons.
- Use clear and plain language and include the nature of the breach, contact point, likely consequences, and measures taken or proposed.
- Article 34(3) exceptions require separate fact-specific verification; do not assert an exception merely because data was described as encrypted or deleted.

## Role rules

- The controller makes the Article 33 and 34 decisions and remains accountable for them.
- The processor notifies the controller without undue delay after becoming aware of a breach. Do not make the processor complete the controller's risk assessment as a precondition to notifying the controller.
- Joint controllers should be assessed against their agreed allocation of notification responsibilities; do not invent a lead authority or local procedural rule.

## Awareness and phased action

Use the controller's awareness point as the time from which the 72-hour period is considered. Keep the first alert and later investigation milestones separate. Do not wait for complete forensic certainty before assessing whether a notification may be required. When information is incomplete, consider an initial notification with later updates rather than silently delaying action.

## Interpretation discipline

These rules establish the legal baseline. EDPB examples guide fact-sensitive reasoning but do not create a mechanical scoring formula. Local supervisory-authority procedure, other laws, and sector-specific obligations remain outside V0.1.
